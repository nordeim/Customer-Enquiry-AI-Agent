import { z } from 'zod';

/**
 * Message schema with Singapore-specific cultural context
 * Implements PDPA compliance through metadata tracking
 */

export const singlishTokenSchema = z.object({
  token: z.string(),
  intent: z.enum([
    'feasibility_check',    // "can or not"
    'frustration',          // "wah lau"
    'temporal_reference',   // "tomolo"
    'apology',              // "paiseh"
    'emphasis',             // "lah", "leh", "lor"
    'question',             // "meh", "hor"
    'surprise',             // "wah"
    'disappointment'        // "aiyah", "aiyoh"
  ]),
  sentiment: z.number().min(-1.0).max(1.0), // -1.0 (negative) to 1.0 (positive)
  confidence: z.number().min(0.0).max(1.0), // 0.0 to 1.0
  translation: z.string().optional(), // Standard English equivalent
});

export const culturalMetaSchema = z.object({
  languageMode: z.enum(['en-SG', 'singlish', 'zh-SG', 'ms-SG', 'ta-SG', 'code-switch']),
  tokens: z.array(singlishTokenSchema).optional(),
  confidence: z.number().min(0.0).max(1.0),
  requiresCulturalAdaptation: z.boolean().default(false),
  politenessLevel: z.enum(['formal', 'casual', 'friendly', 'urgent']).default('casual'),
});

export const piiMetadataSchema = z.object({
  redacted: z.boolean(),
  entities: z.array(z.object({
    type: z.enum(['NRIC', 'FIN', 'PHONE_SG', 'EMAIL', 'ADDRESS', 'CREDIT_CARD']),
    original: z.string(), // Hashed, not stored plaintext
    replacement: z.string(),
    position: z.object({ start: z.number(), end: z.number() }),
  })).optional(),
  consentCaptured: z.boolean().optional(), // PDPA requirement
  consentType: z.enum(['explicit', 'implied', 'withdrawn']).optional(),
});

export const messageSchema = z.object({
  id: z.string().uuid(),
  conversationId: z.string().uuid(),
  sender: z.enum(['user', 'agent', 'system', 'human_escalated']),
  text: z.string(),
  
  // Singapore-specific fields
  originalText: z.string().optional(), // Before any processing
  culturalMeta: culturalMetaSchema.optional(),
  
  // Compliance metadata
  metadata: z.object({
    pii: piiMetadataSchema,
    timestamp: z.string().datetime(),
    messageId: z.string().optional(), // WhatsApp message ID
    userId: z.string().optional(), // Hashed phone number
    sessionId: z.string().uuid().optional(),
    
    // Business context
    requiresEscalation: z.boolean().default(false),
    escalationReason: z.enum(['complex_query', 'complaint', 'technical_issue', 'pii_leak', 'cultural_mismatch']).optional(),
    resolutionTime: z.number().optional(), // seconds
    
    // Singapore business context
    businessContext: z.object({
      uen: z.string(), // Unique Entity Number
      industry: z.enum(['f&b', 'retail', 'logistics', 'professional_services', 'healthcare', 'education']),
      gstRegistered: z.boolean(),
      operatingHours: z.object({
        start: z.string(), // HH:MM format
        end: z.string(),   // HH:MM format
        timezone: z.literal('Asia/Singapore'),
      }),
    }).optional(),
  }),
  
  // Status tracking
  status: z.enum(['sending', 'sent', 'delivered', 'read', 'failed']),
  
  // Agent reasoning (for transparency)
  reasoning: z.object({
    intent: z.string().optional(),
    confidence: z.number().min(0.0).max(1.0).optional(),
    retrievedChunks: z.array(z.object({
      id: z.string(),
      content: z.string(),
      score: z.number(),
      source: z.string(),
    })).optional(),
  }).optional(),
});

export const conversationSchema = z.object({
  id: z.string().uuid(),
  userId: z.string(),
  status: z.enum(['active', 'closed', 'escalated', 'waiting']),
  startedAt: z.string().datetime(),
  lastActivity: z.string().datetime(),
  messages: z.array(messageSchema),
  
  // Singapore-specific metrics
  metrics: z.object({
    singlishRatio: z.number().min(0.0).max(1.0).optional(),
    averageResponseTime: z.number().optional(),
    resolutionRate: z.number().min(0.0).max(1.0).optional(),
    customerSatisfaction: z.number().min(1.0).max(5.0).optional(),
  }).optional(),
  
  // Escalation tracking
  escalation: z.object({
    escalatedAt: z.string().datetime().optional(),
    escalatedTo: z.string().optional(), // User ID of human agent
    reason: z.string().optional(),
    resolution: z.string().optional(),
  }).optional(),
});

// WhatsApp-specific schemas
export const whatsappMessageSchema = z.object({
  id: z.string(),
  from: z.string(), // Phone number
  timestamp: z.string(),
  type: z.enum(['text', 'image', 'document', 'location', 'interactive']),
  text: z.object({
    body: z.string(),
  }).optional(),
  context: z.object({
    messageId: z.string().optional(),
  }).optional(),
});

export const whatsappWebhookSchema = z.object({
  object: z.literal('whatsapp_business_account'),
  entry: z.array(z.object({
    id: z.string(),
    changes: z.array(z.object({
      value: z.object({
        metadata: z.object({
          phone_number_id: z.string(),
          display_phone_number: z.string(),
        }),
        contacts: z.array(z.object({
          wa_id: z.string(),
          profile: z.object({
            name: z.string(),
          }),
        })).optional(),
        messages: z.array(whatsappMessageSchema).optional(),
      }),
      field: z.literal('messages'),
    })),
  })),
});

// Export types
export type SinglishToken = z.infer<typeof singlishTokenSchema>;
export type CulturalMeta = z.infer<typeof culturalMetaSchema>;
export type PIIMetadata = z.infer<typeof piiMetadataSchema>;
export type Message = z.infer<typeof messageSchema>;
export type Conversation = z.infer<typeof conversationSchema>;
export type WhatsAppMessage = z.infer<typeof whatsappMessageSchema>;
export type WhatsAppWebhook = z.infer<typeof whatsappWebhookSchema>;