// Export all type schemas
export * from './message';
export * from './agent';

// Utility types for Singapore-specific contexts
export interface SingaporeBusinessContext {
  uen: string;
  industry: 'f&b' | 'retail' | 'logistics' | 'professional_services' | 'healthcare' | 'education';
  gstRegistered: boolean;
  staffSize: number;
  operatingHours: {
    start: string; // HH:MM format
    end: string;   // HH:MM format
    timezone: 'Asia/Singapore';
  };
  preferredLanguage: 'en' | 'zh' | 'ms' | 'ta';
  address?: {
    street: string;
    postalCode: string;
    region: string;
  };
}

export interface SingaporeComplianceMetrics {
  consentRate: number; // percentage
  piiDetectionAccuracy: number; // percentage
  complianceIncidents: number; // monthly count
  auditReadiness: boolean;
  dataResidency: 'Singapore' | 'Multi-region';
}

export interface PSGrantMetrics {
  eligibility: boolean;
  estimatedAmount: number; // SGD
  automationPercentage: number;
  roiProjection: {
    paybackPeriodMonths: number;
    annualSavings: number;
  };
}

// WebSocket event types
export interface WSEvent {
  type: 'new_message' | 'agent_thought' | 'pii_detected' | 'human_escalation' | 'session_update';
  data: Record<string, any>;
  timestamp: string; // ISO 8601
  sessionId: string;
}

export interface WSCommand {
  action: 'takeover' | 'send_message' | 'resolve' | 'get_context';
  payload: {
    conversationId: string;
    text?: string;
    userId?: string;
  };
  timestamp: string;
}