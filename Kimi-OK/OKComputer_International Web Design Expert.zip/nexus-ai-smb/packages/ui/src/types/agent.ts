import { z } from 'zod';

/**
 * Agent state and reasoning schemas
 * Implements LangGraph-compatible state management
 */

// Agent state machine
export const agentStateSchema = z.object({
  // Core conversation state
  sessionId: z.string().uuid(),
  userId: z.string(),
  messages: z.array(z.object({
    id: z.string().uuid(),
    role: z.enum(['user', 'assistant', 'system']),
    content: z.string(),
    timestamp: z.string().datetime(),
  })),
  
  // Agent reasoning state
  currentStep: z.enum([
    'idle',
    'pii_check',
    'intent_classify', 
    'cultural_analysis',
    'rag_retrieve',
    'llm_generate',
    'safety_check',
    'response_deliver',
    'error_handle'
  ]),
  
  // Memory layers (Singapore-optimized)
  longTermFacts: z.array(z.string()),
  shortTermContext: z.array(z.string()),
  workingMemory: z.string(),
  
  // Singapore-specific state
  singaporeContext: z.object({
    detectedLanguage: z.enum(['en-SG', 'singlish', 'zh-SG', 'ms-SG', 'ta-SG', 'code-switch']),
    culturalAdaptationNeeded: z.boolean(),
    politenessLevel: z.enum(['formal', 'casual', 'friendly', 'urgent']),
    gstRegistered: z.boolean().optional(),
    industryContext: z.string().optional(),
  }),
  
  // PDPA compliance state
  pdpaState: z.object({
    consentCaptured: z.boolean(),
    consentType: z.enum(['explicit', 'implied', 'withdrawn']).optional(),
    piiDetected: z.boolean(),
    redactedEntities: z.array(z.object({
      type: z.string(),
      originalHash: z.string(), // Hashed for privacy
      replacement: z.string(),
    })),
    dataRetentionExpiry: z.string().datetime().optional(),
  }),
  
  // Escalation tracking
  escalationRisk: z.number().min(0.0).max(1.0),
  escalationReason: z.string().optional(),
  humanAvailable: z.boolean(),
  
  // Performance metrics
  startTime: z.string().datetime(),
  stepTimings: z.record(z.string(), z.number()),
});

// Agent configuration
export const agentConfigSchema = z.object({
  // LLM settings
  llm: z.object({
    model: z.enum(['gpt-4o-mini', 'gpt-4o', 'gpt-3.5-turbo']),
    temperature: z.number().min(0.0).max(2.0),
    maxTokens: z.number().int().positive(),
    topP: z.number().min(0.0).max(1.0),
  }),
  
  // RAG settings
  rag: z.object({
    topK: z.number().int().positive().max(20),
    scoreThreshold: z.number().min(0.0).max(1.0),
    hybridSearch: z.boolean(),
    rerank: z.boolean(),
  }),
  
  // Singapore-specific settings
  singapore: z.object({
    singlishMode: z.enum(['auto', 'always', 'never']),
    culturalAdaptation: z.boolean(),
    politenessDefault: z.enum(['formal', 'casual', 'friendly']),
    businessHoursOnly: z.boolean(),
  }),
  
  // Compliance settings
  compliance: z.object({
    pdpaMode: z.enum(['strict', 'permissive', 'bypass']),
    auditEverything: z.boolean(),
    dataRetentionDays: z.number().int().positive(),
  }),
  
  // Escalation rules
  escalation: z.object({
    enabled: z.boolean(),
    confidenceThreshold: z.number().min(0.0).max(1.0),
    sentimentThreshold: z.number().min(-1.0).max(0.0),
    timeoutSeconds: z.number().int().positive(),
  }),
});

// Agent reasoning trace
export const reasoningStepSchema = z.object({
  step: z.string(),
  type: z.enum(['intent', 'retrieval', 'generation', 'safety', 'escalation']),
  input: z.string().optional(),
  output: z.string().optional(),
  confidence: z.number().min(0.0).max(1.0).optional(),
  timestamp: z.string().datetime(),
  latencyMs: z.number().int().positive(),
  
  // Singapore-specific reasoning
  culturalNotes: z.array(z.object({
    detected: z.string(),
    action: z.string(),
    reason: z.string(),
  })).optional(),
  
  // Retrieval details
  retrievedChunks: z.array(z.object({
    id: z.string(),
    content: z.string(),
    score: z.number(),
    source: z.string(),
    relevance: z.number().min(0.0).max(1.0),
  })).optional(),
  
  // Safety checks
  safetyChecks: z.array(z.object({
    check: z.string(),
    passed: z.boolean(),
    details: z.string().optional(),
  })).optional(),
});

// Agent response
export const agentResponseSchema = z.object({
  message: z.object({
    content: z.string(),
    role: z.literal('assistant'),
    timestamp: z.string().datetime(),
  }),
  
  reasoning: z.object({
    steps: z.array(reasoningStepSchema),
    totalLatencyMs: z.number().int().positive(),
    confidence: z.number().min(0.0).max(1.0),
    culturalAdaptation: z.boolean(),
  }),
  
  metadata: z.object({
    sessionId: z.string().uuid(),
    messageId: z.string().uuid(),
    requiresEscalation: z.boolean(),
    escalationReason: z.string().optional(),
    piiDetected: z.boolean(),
    tokensUsed: z.object({
      prompt: z.number().int().nonnegative(),
      completion: z.number().int().nonnegative(),
      total: z.number().int().nonnegative(),
    }).optional(),
  }),
  
  // Singapore-specific response metadata
  singapore: z.object({
    detectedLanguage: z.string(),
    culturalContext: z.object({
      politenessLevel: z.string(),
      formality: z.enum(['formal', 'semi-formal', 'casual']),
      localReferences: z.array(z.string()).optional(),
    }),
    complianceFlags: z.array(z.string()).optional(),
  }),
});

// Export types
export type AgentState = z.infer<typeof agentStateSchema>;
export type AgentConfig = z.infer<typeof agentConfigSchema>;
export type ReasoningStep = z.infer<typeof reasoningStepSchema>;
export type AgentResponse = z.infer<typeof agentResponseSchema>;