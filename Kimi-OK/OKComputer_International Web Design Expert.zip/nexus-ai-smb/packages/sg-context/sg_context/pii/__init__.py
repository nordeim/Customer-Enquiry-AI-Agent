"""
PII Detection module for Singapore-specific personal information
"""

from .detector import SingaporePIIDetector, RedactionResult

__all__ = ["SingaporePIIDetector", "RedactionResult"]