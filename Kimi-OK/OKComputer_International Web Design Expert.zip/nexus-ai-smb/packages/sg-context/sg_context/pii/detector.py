"""
Singapore PII Detector - Enhanced PII detection for Singapore context
Integrates with Microsoft Presidio for comprehensive PII detection
"""

import hashlib
import re
from typing import List, Dict, Any, Optional
from pydantic import BaseModel, Field


class RedactionResult(BaseModel):
    """Result of PII redaction operation"""
    text: str
    entities: List[Dict[str, Any]]
    redacted: bool
    redaction_count: int = 0
    risk_score: float = Field(ge=0.0, le=1.0, default=0.0)


class SingaporePIIDetector:
    """
    Enhanced PII detector for Singapore-specific formats
    
    Rationale: Singapore has unique PII formats (NRIC/FIN) that require
    specialized detection. This ensures PDPA compliance by detecting and
    redacting all forms of personal data before processing.
    """
    
    def __init__(self):
        """Initialize Singapore PII detector"""
        self.sg_patterns = self._compile_sg_patterns()
        
    def _compile_sg_patterns(self) -> Dict[str, re.Pattern]:
        """Compile Singapore-specific PII patterns"""
        patterns = {
            # NRIC/FIN patterns
            "nric_fin": re.compile(r"[STFGstfg]\d{7}[A-Za-z]", re.IGNORECASE),
            
            # Singapore phone numbers (mobile and landline)
            "phone_sg": re.compile(r"(\+65)?\s*(\d{4}\s?\d{4}|\d{3}\s?\d{3}\s?\d{4})", re.IGNORECASE),
            
            # Singapore postal codes
            "postal_code": re.compile(r"\d{6}", re.IGNORECASE),
            
            # Email addresses (general pattern)
            "email": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"),
            
            # Credit card numbers (general pattern)
            "credit_card": re.compile(r"\b(?:\d{4}[-\s]?){3}\d{4}\b"),
            
            # NRIC with common prefixes
            "nric_explicit": re.compile(
                r"\b(?:nric|fin|ic|identity\s+card)\s*:?\s*[STFG]\d{7}[A-Z]\b",
                re.IGNORECASE
            ),
            
            # Phone with explicit labels
            "phone_explicit": re.compile(
                r"\b(?:phone|mobile|hp|handphone|tel)\s*:?\s*(?:\+65)?\s*\d{4}\s?\d{4}\b",
                re.IGNORECASE
            ),
        }
        return patterns
    
    def redact(self, text: str, include_general: bool = True) -> RedactionResult:
        """
        Redact PII from text
        
        Args:
            text: Input text to redact
            include_general: Whether to include general PII patterns (email, etc.)
            
        Returns:
            RedactionResult with redacted text and metadata
        """
        if not text:
            return RedactionResult(
                text=text,
                entities=[],
                redacted=False,
                redaction_count=0,
                risk_score=0.0
            )
        
        entities = []
        redacted_text = text
        
        # Detect Singapore-specific PII
        for entity_type, pattern in self.sg_patterns.items():
            for match in pattern.finditer(text):
                original = match.group()
                
                # Skip if it's a false positive (e.g., date looking like postal code)
                if self._is_false_positive(original, entity_type):
                    continue
                
                # Generate replacement
                replacement = self._generate_replacement(original, entity_type)
                
                # Hash the original value for audit (not stored in response)
                original_hash = hashlib.sha256(original.encode()).hexdigest()[:16]
                
                entity = {
                    "type": entity_type,
                    "original_hash": original_hash,  # Hashed for privacy
                    "replacement": replacement,
                    "position": {"start": match.start(), "end": match.end()},
                    "confidence": self._calculate_confidence(original, entity_type)
                }
                
                entities.append(entity)
                
                # Replace in text
                redacted_text = (
                    redacted_text[:match.start()] + 
                    replacement + 
                    redacted_text[match.end():]
                )
        
        # Calculate risk score
        risk_score = self._calculate_risk_score(entities, len(text))
        
        return RedactionResult(
            text=redacted_text,
            entities=entities,
            redacted=len(entities) > 0,
            redaction_count=len(entities),
            risk_score=risk_score
        )
    
    def detect_only(self, text: str) -> List[Dict[str, Any]]:
        """
        Detect PII without redaction (for analysis)
        
        Args:
            text: Input text to analyze
            
        Returns:
            List of detected entities
        """
        entities = []
        
        for entity_type, pattern in self.sg_patterns.items():
            for match in pattern.finditer(text):
                original = match.group()
                
                if self._is_false_positive(original, entity_type):
                    continue
                
                entity = {
                    "type": entity_type,
                    "value": original,
                    "position": {"start": match.start(), "end": match.end()},
                    "confidence": self._calculate_confidence(original, entity_type)
                }
                entities.append(entity)
        
        return entities
    
    def validate_nric(self, nric: str) -> bool:
        """
        Validate NRIC/FIN using checksum algorithm
        
        Args:
            nric: NRIC/FIN number to validate
            
        Returns:
            True if valid, False otherwise
        """
        nric = nric.upper().strip()
        
        # Basic format check
        if not re.match(r"^[STFG]\d{7}[A-Z]$", nric):
            return False
        
        # Extract components
        prefix = nric[0]
        digits = nric[1:8]
        checksum = nric[8]
        
        # Weights for checksum calculation
        weights = [2, 7, 6, 5, 4, 3, 2]
        
        # Calculate weighted sum
        weighted_sum = sum(int(digit) * weight for digit, weight in zip(digits, weights))
        
        # Adjust for prefix
        if prefix in ["T", "G"]:
            weighted_sum += 4
        
        # Calculate checksum
        remainder = weighted_sum % 11
        
        # Checksum mapping
        checksum_map = {
            0: "J", 1: "Z", 2: "I", 3: "H", 4: "G", 5: "F",
            6: "E", 7: "D", 8: "C", 9: "B", 10: "A"
        }
        
        if prefix in ["T", "G"]:
            checksum_map = {
                0: "X", 1: "W", 2: "U", 3: "T", 4: "R", 5: "Q",
                6: "P", 7: "N", 8: "M", 9: "L", 10: "K"
            }
        
        expected_checksum = checksum_map.get(remainder, "")
        
        return checksum == expected_checksum
    
    def validate_phone_sg(self, phone: str) -> bool:
        """
        Validate Singapore phone number
        
        Args:
            phone: Phone number to validate
            
        Returns:
            True if valid Singapore phone number
        """
        # Remove common separators
        clean_phone = re.sub(r'[\s\-\+]', '', phone)
        
        # Singapore mobile numbers: 8 or 9 followed by 7 digits
        if re.match(r"^[89]\d{7}$", clean_phone):
            return True
        
        # Singapore landline: 6 followed by 7 digits
        if re.match(r"^6\d{7}$", clean_phone):
            return True
        
        return False
    
    def _is_false_positive(self, text: str, entity_type: str) -> bool:
        """Check if detection is a false positive"""
        text = text.strip()
        
        if entity_type == "postal_code":
            # Postal codes are 6 digits, but avoid dates and other numbers
            # Check if it's a standalone 6-digit number
            if not re.match(r"^\d{6}$", text):
                return True
            
            # Avoid years (e.g., 2024)
            if int(text) > 1900 and int(text) < 2100:
                return True
        
        if entity_type == "nric_fin":
            # Validate checksum for NRIC/FIN
            if not self.validate_nric(text):
                return True
        
        if entity_type == "phone_sg":
            # Validate phone format
            if not self.validate_phone_sg(text):
                return True
        
        return False
    
    def _generate_replacement(self, original: str, entity_type: str) -> str:
        """Generate replacement text for redacted PII"""
        replacements = {
            "nric_fin": "<NRIC_REDACTED>",
            "nric_explicit": "<NRIC_REDACTED>",
            "phone_sg": "<PHONE_SG>",
            "phone_explicit": "<PHONE_SG>",
            "postal_code": "<POSTAL_CODE>",
            "email": "<EMAIL_ADDRESS>",
            "credit_card": "<CREDIT_CARD>",
        }
        
        return replacements.get(entity_type, f"<{entity_type.upper()}>")
    
    def _calculate_confidence(self, original: str, entity_type: str) -> float:
        """Calculate confidence score for detection"""
        base_confidence = 0.8
        
        # Boost confidence for explicit patterns
        if "explicit" in entity_type:
            base_confidence += 0.15
        
        # Validate format-specific patterns
        if entity_type == "nric_fin" and self.validate_nric(original):
            base_confidence += 0.1
        
        if entity_type == "phone_sg" and self.validate_phone_sg(original):
            base_confidence += 0.1
        
        return min(base_confidence, 1.0)
    
    def _calculate_risk_score(self, entities: List[Dict[str, Any]], text_length: int) -> float:
        """Calculate overall risk score based on detected entities"""
        if not entities:
            return 0.0
        
        # Weight different PII types
        weights = {
            "nric_fin": 1.0,
            "nric_explicit": 1.0,
            "phone_sg": 0.8,
            "phone_explicit": 0.8,
            "email": 0.7,
            "credit_card": 1.0,
            "postal_code": 0.3,
        }
        
        total_weight = sum(weights.get(e["type"], 0.5) for e in entities)
        
        # Normalize by text length (longer texts with same PII = lower risk)
        normalized_risk = total_weight / max(text_length / 100, 1.0)
        
        return min(normalized_risk, 1.0)