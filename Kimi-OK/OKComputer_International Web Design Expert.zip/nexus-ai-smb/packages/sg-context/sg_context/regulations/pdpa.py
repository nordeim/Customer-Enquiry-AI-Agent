"""
PDPA (Personal Data Protection Act) compliance engine for Singapore
Implements automated audit trails and consent management
"""

import json
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from enum import Enum
from pydantic import BaseModel, Field


class ConsentType(str, Enum):
    """Types of consent under PDPA"""
    EXPLICIT = "explicit"
    IMPLIED = "implied"
    WITHDRAWN = "withdrawn"


class DataPurpose(str, Enum):
    """Purposes for data collection under PDPA"""
    CUSTOMER_SERVICE = "customer_service"
    MARKETING = "marketing"
    ANALYTICS = "analytics"
    LEGAL_COMPLIANCE = "legal_compliance"
    FRAUD_PREVENTION = "fraud_prevention"


class AuditAction(str, Enum):
    """Audit actions for PDPA compliance"""
    DATA_COLLECTED = "data_collected"
    DATA_ACCESSED = "data_accessed"
    DATA_MODIFIED = "data_modified"
    DATA_DELETED = "data_deleted"
    CONSENT_GIVEN = "consent_given"
    CONSENT_WITHDRAWN = "consent_withdrawn"
    BREACH_DETECTED = "breach_detected"
    COMPLAINT_RECEIVED = "complaint_received"


class ConsentRecord(BaseModel):
    """Record of consent given by user"""
    user_id: str
    consent_type: ConsentType
    purposes: List[DataPurpose]
    timestamp: datetime
    expiry_date: Optional[datetime] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    
    def is_valid(self) -> bool:
        """Check if consent is still valid"""
        if self.consent_type == ConsentType.WITHDRAWN:
            return False
        if self.expiry_date and datetime.now() > self.expiry_date:
            return False
        return True


class AuditLogEntry(BaseModel):
    """Individual audit log entry"""
    id: str
    user_id: str
    action: AuditAction
    timestamp: datetime
    details: Dict[str, Any] = Field(default_factory=dict)
    ip_address: Optional[str] = None
    session_id: Optional[str] = None
    data_types: List[str] = Field(default_factory=list)
    risk_level: str = Field(default="low")  # low, medium, high, critical
    
    def get_hash(self) -> str:
        """Generate hash for tamper detection"""
        data = f"{self.id}{self.user_id}{self.timestamp.isoformat()}{json.dumps(self.details, sort_keys=True)}"
        return hashlib.sha256(data.encode()).hexdigest()


class DataBreach(BaseModel):
    """Data breach incident record"""
    id: str
    detected_at: datetime
    severity: str  # low, medium, high, critical
    affected_users: int
    data_types_affected: List[str]
    description: str
    root_cause: Optional[str] = None
    containment_actions: List[str] = Field(default_factory=list)
    notification_status: str = "pending"  # pending, notified, resolved
    pdpc_notified: bool = False
    
    def requires_pdpc_notification(self) -> bool:
        """Check if PDPC notification is required (>500 users)"""
        return self.affected_users >= 500
    
    def notification_deadline(self) -> datetime:
        """Calculate PDPC notification deadline (72 hours)"""
        return self.detected_at + timedelta(hours=72)


class PDPAGuidelines:
    """
    PDPA compliance engine for Singapore SMBs
    
    Implements the Personal Data Protection Act 2012 requirements:
    - Consent Obligation
    - Purpose Limitation Obligation  
    - Notification Obligation
    - Access and Correction Obligation
    - Accuracy Obligation
    - Protection Obligation
    - Retention Limitation Obligation
    - Transfer Limitation Obligation
    - Openness Obligation
    """
    
    def __init__(self):
        """Initialize PDPA compliance engine"""
        self.consent_records: Dict[str, List[ConsentRecord]] = {}
        self.audit_logs: List[AuditLogEntry] = []
        self.data_breaches: List[DataBreach] = []
        
        # Default retention periods (in days)
        self.retention_periods = {
            DataPurpose.CUSTOMER_SERVICE: 90,
            DataPurpose.MARKETING: 365,
            DataPurpose.ANALYTICS: 730,
            DataPurpose.LEGAL_COMPLIANCE: 2555,  # 7 years
            DataPurpose.FRAUD_PREVENTION: 1825,  # 5 years
        }
        
        # PDPA notification templates
        self.notification_templates = self._load_templates()
    
    def record_consent(
        self,
        user_id: str,
        consent_type: ConsentType,
        purposes: List[DataPurpose],
        ip_address: Optional[str] = None,
        user_agent: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> ConsentRecord:
        """
        Record user consent for data collection
        
        Args:
            user_id: Unique identifier for user
            consent_type: Type of consent given
            purposes: List of purposes for data collection
            ip_address: IP address of user (for audit)
            user_agent: User agent string (for audit)
            metadata: Additional metadata
            
        Returns:
            ConsentRecord object
        """
        record = ConsentRecord(
            user_id=user_id,
            consent_type=consent_type,
            purposes=purposes,
            timestamp=datetime.now(),
            ip_address=ip_address,
            user_agent=user_agent,
            metadata=metadata or {}
        )
        
        # Store consent record
        if user_id not in self.consent_records:
            self.consent_records[user_id] = []
        self.consent_records[user_id].append(record)
        
        # Log the consent action
        self.log_audit(
            user_id=user_id,
            action=AuditAction.CONSENT_GIVEN,
            details={
                "consent_type": consent_type.value,
                "purposes": [p.value for p in purposes],
                "metadata": metadata
            },
            data_types=["consent"],
            risk_level="low"
        )
        
        return record
    
    def withdraw_consent(self, user_id: str, ip_address: Optional[str] = None) -> bool:
        """
        Withdraw consent for data processing
        
        Args:
            user_id: User ID withdrawing consent
            ip_address: IP address for audit
            
        Returns:
            True if consent was withdrawn successfully
        """
        if user_id not in self.consent_records:
            return False
        
        # Add withdrawal record
        withdrawal_record = ConsentRecord(
            user_id=user_id,
            consent_type=ConsentType.WITHDRAWN,
            purposes=[],
            timestamp=datetime.now(),
            ip_address=ip_address
        )
        
        self.consent_records[user_id].append(withdrawal_record)
        
        # Log withdrawal
        self.log_audit(
            user_id=user_id,
            action=AuditAction.CONSENT_WITHDRAWN,
            details={"all_purposes": True},
            data_types=["consent"],
            risk_level="medium"
        )
        
        return True
    
    def check_consent(self, user_id: str, purpose: DataPurpose) -> bool:
        """
        Check if user has given consent for a specific purpose
        
        Args:
            user_id: User ID to check
            purpose: Data processing purpose
            
        Returns:
            True if valid consent exists
        """
        if user_id not in self.consent_records:
            return False
        
        # Check most recent consent records
        for record in reversed(self.consent_records[user_id]):
            if record.is_valid() and purpose in record.purposes:
                return True
            elif record.consent_type == ConsentType.WITHDRAWN:
                return False
        
        return False
    
    def log_audit(
        self,
        user_id: str,
        action: AuditAction,
        details: Dict[str, Any],
        ip_address: Optional[str] = None,
        session_id: Optional[str] = None,
        data_types: Optional[List[str]] = None,
        risk_level: str = "low"
    ) -> AuditLogEntry:
        """
        Create audit log entry for PDPA compliance
        
        Args:
            user_id: User ID associated with action
            action: Action performed
            details: Additional details about the action
            ip_address: IP address for audit
            session_id: Session ID for correlation
            data_types: Types of data involved
            risk_level: Risk level of the action
            
        Returns:
            AuditLogEntry object
        """
        entry = AuditLogEntry(
            id=self._generate_audit_id(),
            user_id=user_id,
            action=action,
            timestamp=datetime.now(),
            details=details,
            ip_address=ip_address,
            session_id=session_id,
            data_types=data_types or [],
            risk_level=risk_level
        )
        
        self.audit_logs.append(entry)
        
        # Maintain tamper-evident hash chain
        if len(self.audit_logs) > 1:
            prev_hash = self.audit_logs[-2].get_hash()
            entry.details["previous_hash"] = prev_hash
        
        return entry
    
    def record_data_breach(
        self,
        severity: str,
        affected_users: int,
        data_types_affected: List[str],
        description: str,
        root_cause: Optional[str] = None
    ) -> DataBreach:
        """
        Record a data breach incident
        
        Args:
            severity: Severity level (low, medium, high, critical)
            affected_users: Number of users affected
            data_types_affected: Types of data compromised
            description: Description of the breach
            root_cause: Root cause analysis
            
        Returns:
            DataBreach object
        """
        breach = DataBreach(
            id=self._generate_breach_id(),
            detected_at=datetime.now(),
            severity=severity,
            affected_users=affected_users,
            data_types_affected=data_types_affected,
            description=description,
            root_cause=root_cause
        )
        
        self.data_breaches.append(breach)
        
        # Log the breach
        self.log_audit(
            user_id="system",
            action=AuditAction.BREACH_DETECTED,
            details={
                "breach_id": breach.id,
                "severity": severity,
                "affected_users": affected_users,
                "data_types": data_types_affected,
                "description": description
            },
            data_types=data_types_affected,
            risk_level=severity
        )
        
        # Check if PDPC notification is required
        if breach.requires_pdpc_notification():
            breach.notification_status = "pending"
        
        return breach
    
    def get_retention_period(self, purpose: DataPurpose) -> int:
        """Get retention period in days for a specific purpose"""
        return self.retention_periods.get(purpose, 365)
    
    def is_retention_expired(self, record_date: datetime, purpose: DataPurpose) -> bool:
        """Check if data retention period has expired"""
        retention_days = self.get_retention_period(purpose)
        expiry_date = record_date + timedelta(days=retention_days)
        return datetime.now() > expiry_date
    
    def generate_compliance_report(self, start_date: datetime, end_date: datetime) -> Dict[str, Any]:
        """
        Generate PDPA compliance report for a date range
        
        Args:
            start_date: Start of report period
            end_date: End of report period
            
        Returns:
            Compliance report dictionary
        """
        # Filter audit logs for period
        period_logs = [
            log for log in self.audit_logs
            if start_date <= log.timestamp <= end_date
        ]
        
        # Calculate metrics
        total_actions = len(period_logs)
        high_risk_actions = len([log for log in period_logs if log.risk_level == "high"])
        data_breaches = len([log for log in period_logs if log.action == AuditAction.BREACH_DETECTED])
        
        # Consent metrics
        total_consents = len([
            log for log in period_logs 
            if log.action == AuditAction.CONSENT_GIVEN
        ])
        withdrawals = len([
            log for log in period_logs 
            if log.action == AuditAction.CONSENT_WITHDRAWN
        ])
        
        return {
            "report_period": {
                "start": start_date.isoformat(),
                "end": end_date.isoformat()
            },
            "summary": {
                "total_audit_actions": total_actions,
                "high_risk_actions": high_risk_actions,
                "data_breaches": data_breaches,
                "consents_given": total_consents,
                "consents_withdrawn": withdrawals,
                "compliance_score": self._calculate_compliance_score(period_logs)
            },
            "audit_trail": [log.dict() for log in period_logs],
            "recommendations": self._generate_recommendations(period_logs)
        }
    
    def _generate_audit_id(self) -> str:
        """Generate unique audit ID"""
        timestamp = datetime.now().isoformat()
        return f"audit_{hashlib.md5(timestamp.encode()).hexdigest()[:12]}"
    
    def _generate_breach_id(self) -> str:
        """Generate unique breach ID"""
        timestamp = datetime.now().isoformat()
        return f"breach_{hashlib.md5(timestamp.encode()).hexdigest()[:12]}"
    
    def _calculate_compliance_score(self, logs: List[AuditLogEntry]) -> float:
        """Calculate compliance score based on audit logs"""
        if not logs:
            return 1.0
        
        # Penalty points for violations
        penalties = {
            "low": 0.01,
            "medium": 0.05,
            "high": 0.1,
            "critical": 0.2
        }
        
        total_penalty = sum(penalties.get(log.risk_level, 0.01) for log in logs)
        max_penalty = len(logs) * 0.2  # Assume worst case all critical
        
        if max_penalty == 0:
            return 1.0
        
        compliance_score = 1.0 - (total_penalty / max_penalty)
        return max(0.0, compliance_score)
    
    def _generate_recommendations(self, logs: List[AuditLogEntry]) -> List[str]:
        """Generate compliance recommendations based on audit logs"""
        recommendations = []
        
        high_risk_logs = [log for log in logs if log.risk_level in ["high", "critical"]]
        breach_logs = [log for log in logs if log.action == AuditAction.BREACH_DETECTED]
        
        if high_risk_logs:
            recommendations.append(
                f"Review {len(high_risk_logs)} high-risk actions and implement additional controls"
            )
        
        if breach_logs:
            recommendations.append(
                "Immediate action required: Data breach detected. Review containment procedures."
            )
        
        if not any(log.action == AuditAction.CONSENT_GIVEN for log in logs):
            recommendations.append(
                "No consent records found. Implement explicit consent collection for all users."
            )
        
        return recommendations
    
    def _load_templates(self) -> Dict[str, str]:
        """Load PDPA notification templates"""
        return {
            "consent_request": """
We collect your personal data to provide customer service and improve our products. 
Your data will be used for: {purposes}

You may withdraw your consent at any time by contacting us.
            """.strip(),
            
            "data_breach_notification": """
We are writing to inform you of a data breach that may have affected your personal information.

Affected data: {data_types}
Incident date: {incident_date}
Actions taken: {actions}

We sincerely apologize for this incident and have implemented additional security measures.
            """.strip(),
        }