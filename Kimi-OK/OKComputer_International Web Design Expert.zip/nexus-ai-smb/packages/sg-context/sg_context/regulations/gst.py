"""
GST (Goods and Services Tax) utilities for Singapore SMBs
Handles GST calculations and compliance for 9% GST rate (2024)
"""

from decimal import Decimal, ROUND_HALF_UP
from typing import Dict, List, Optional
from datetime import datetime
from pydantic import BaseModel, Field


class GSTCalculation(BaseModel):
    """GST calculation result"""
    original_amount: Decimal
    gst_rate: Decimal = Field(default=Decimal("0.09"))  # 9% GST
    gst_amount: Decimal
    total_amount: Decimal
    is_gst_inclusive: bool
    calculation_date: datetime = Field(default_factory=datetime.now)


class GSTInvoice(BaseModel):
    """GST invoice details"""
    invoice_number: str
    date: datetime
    customer_name: str
    customer_uen: Optional[str] = None  # For GST-registered customers
    items: List[Dict[str, Any]]
    subtotal: Decimal
    gst_amount: Decimal
    total_amount: Decimal
    is_gst_registered: bool
    
    def generate_for_gst_registered(self) -> str:
        """Generate invoice format for GST-registered businesses"""
        lines = []
        lines.append(f"Invoice Number: {self.invoice_number}")
        lines.append(f"Date: {self.date.strftime('%d/%m/%Y')}")
        lines.append(f"Customer: {self.customer_name}")
        if self.customer_uen:
            lines.append(f"Customer UEN: {self.customer_uen}")
        lines.append("")
        lines.append("Items:")
        for item in self.items:
            lines.append(f"  {item['description']}: ${item['amount']:.2f}")
        lines.append("")
        lines.append(f"Subtotal: ${self.subtotal:.2f}")
        lines.append(f"GST (9%): ${self.gst_amount:.2f}")
        lines.append(f"Total: ${self.total_amount:.2f}")
        
        return "\n".join(lines)


class GSTRules:
    """
    GST calculation and compliance utilities for Singapore
    
    Current GST rate: 9% (from 2024)
    Registration threshold: S$1 million annual taxable turnover
    """
    
    def __init__(self):
        """Initialize GST rules"""
        self.gst_rate = Decimal("0.09")  # 9%
        self.registration_threshold = Decimal("1000000")  # S$1 million
        
    def calculate_gst(
        self,
        amount: Decimal,
        is_inclusive: bool = False,
        rate: Optional[Decimal] = None
    ) -> GSTCalculation:
        """
        Calculate GST for a given amount
        
        Args:
            amount: Original amount
            is_inclusive: Whether amount includes GST
            rate: Custom GST rate (uses default if None)
            
        Returns:
            GSTCalculation with breakdown
        """
        gst_rate = rate or self.gst_rate
        
        if is_inclusive:
            # GST-inclusive: extract GST amount
            gst_amount = (amount * gst_rate / (Decimal("1") + gst_rate))
            original_amount = amount - gst_amount
            total_amount = amount
        else:
            # GST-exclusive: add GST amount
            gst_amount = (amount * gst_rate).quantize(
                Decimal("0.01"), rounding=ROUND_HALF_UP
            )
            original_amount = amount
            total_amount = amount + gst_amount
        
        return GSTCalculation(
            original_amount=original_amount,
            gst_rate=gst_rate,
            gst_amount=gst_amount,
            total_amount=total_amount,
            is_gst_inclusive=is_inclusive
        )
    
    def calculate_invoice(
        self,
        items: List[Dict[str, Any]],
        customer_uen: Optional[str] = None,
        is_gst_registered: bool = True
    ) -> GSTInvoice:
        """
        Calculate GST for an invoice
        
        Args:
            items: List of items with 'description' and 'amount'
            customer_uen: Customer's UEN (if GST-registered)
            is_gst_registered: Whether this business is GST-registered
            
        Returns:
            GSTInvoice with calculated amounts
        """
        # Calculate subtotal
        subtotal = sum(Decimal(str(item.get("amount", 0))) for item in items)
        
        # Calculate GST
        if is_gst_registered:
            gst_calculation = self.calculate_gst(subtotal, is_inclusive=False)
            gst_amount = gst_calculation.gst_amount
            total_amount = gst_calculation.total_amount
        else:
            gst_amount = Decimal("0")
            total_amount = subtotal
        
        # Generate invoice number
        invoice_number = self._generate_invoice_number()
        
        return GSTInvoice(
            invoice_number=invoice_number,
            date=datetime.now(),
            customer_name=items[0].get("customer_name", "Customer"),
            customer_uen=customer_uen,
            items=items,
            subtotal=subtotal,
            gst_amount=gst_amount,
            total_amount=total_amount,
            is_gst_registered=is_gst_registered
        )
    
    def requires_gst_registration(self, annual_turnover: Decimal) -> bool:
        """
        Check if business requires GST registration
        
        Args:
            annual_turnover: Annual taxable turnover in SGD
            
        Returns:
            True if GST registration is required
        """
        return annual_turnover >= self.registration_threshold
    
    def get_gst_status(self, annual_turnover: Decimal, is_registered: bool) -> str:
        """
        Get GST registration status
        
        Args:
            annual_turnover: Annual taxable turnover
            is_registered: Whether already registered
            
        Returns:
            GST status description
        """
        if is_registered:
            return "GST-registered"
        elif self.requires_gst_registration(annual_turnover):
            return "Required to register for GST"
        else:
            return "Optional GST registration"
    
    def generate_gst_return_data(
        self,
        period_start: datetime,
        period_end: datetime,
        sales: List[Dict[str, Any]],
        purchases: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Generate GST return data for IRAS filing
        
        Args:
            period_start: Start of GST period
            period_end: End of GST period
            sales: List of sales transactions
            purchases: List of purchase transactions
            
        Returns:
            GST return data structure
        """
        # Calculate output GST (GST collected from sales)
        total_sales = sum(Decimal(str(sale.get("amount", 0))) for sale in sales)
        output_gst = self.calculate_gst(total_sales, is_inclusive=False).gst_amount
        
        # Calculate input GST (GST paid on purchases)
        total_purchases = sum(
            Decimal(str(purchase.get("amount", 0))) for purchase in purchases
        )
        input_gst = self.calculate_gst(total_purchases, is_inclusive=False).gst_amount
        
        # Calculate net GST payable/refundable
        net_gst = output_gst - input_gst
        
        return {
            "period_start": period_start.strftime("%Y-%m-%d"),
            "period_end": period_end.strftime("%Y-%m-%d"),
            "total_sales": float(total_sales),
            "output_gst": float(output_gst),
            "total_purchases": float(total_purchases),
            "input_gst": float(input_gst),
            "net_gst": float(net_gst),
            "gst_payable": float(net_gst) if net_gst > 0 else 0,
            "gst_refundable": float(abs(net_gst)) if net_gst < 0 else 0,
            "transaction_count": {
                "sales": len(sales),
                "purchases": len(purchases)
            }
        }
    
    def validate_gst_invoice(self, invoice: Dict[str, Any]) -> List[str]:
        """
        Validate GST invoice compliance
        
        Args:
            invoice: Invoice data to validate
            
        Returns:
            List of validation errors (empty if valid)
        """
        errors = []
        
        # Check required fields
        required_fields = ["invoice_number", "date", "customer_name", "items"]
        for field in required_fields:
            if field not in invoice or not invoice[field]:
                errors.append(f"Missing required field: {field}")
        
        # Check GST amounts
        if "gst_amount" in invoice and "subtotal" in invoice:
            expected_gst = self.calculate_gst(
                Decimal(str(invoice["subtotal"])), 
                is_inclusive=False
            ).gst_amount
            
            actual_gst = Decimal(str(invoice.get("gst_amount", 0)))
            if abs(expected_gst - actual_gst) > Decimal("0.01"):
                errors.append(f"GST amount mismatch. Expected: {expected_gst}, Actual: {actual_gst}")
        
        # Check invoice date (should not be future date)
        if "date" in invoice:
            try:
                invoice_date = datetime.fromisoformat(invoice["date"])
                if invoice_date > datetime.now():
                    errors.append("Invoice date cannot be in the future")
            except ValueError:
                errors.append("Invalid invoice date format")
        
        return errors
    
    def _generate_invoice_number(self) -> str:
        """Generate unique invoice number"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        return f"INV{timestamp}"
    
    def get_gst_rate_history(self, date: Optional[datetime] = None) -> Decimal:
        """
        Get GST rate applicable for a specific date
        
        Args:
            date: Date to check (defaults to current date)
            
        Returns:
            GST rate as Decimal
        """
        check_date = date or datetime.now()
        
        # GST rate history
        if check_date >= datetime(2024, 1, 1):
            return Decimal("0.09")  # 9% from 2024
        elif check_date >= datetime(2023, 1, 1):
            return Decimal("0.08")  # 8% in 2023
        elif check_date >= datetime(2022, 1, 1):
            return Decimal("0.07")  # 7% in 2022
        else:
            return Decimal("0.07")  # Default to 7% for historical data
    
    def format_currency(self, amount: Decimal) -> str:
        """Format amount as Singapore currency"""
        return f"${amount.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP):,.2f}"
    
    def is_zero_rated_supply(self, item_type: str) -> bool:
        """
        Check if item qualifies for zero-rated GST
        
        Args:
            item_type: Type of item/service
            
        Returns:
            True if zero-rated
        """
        zero_rated_types = [
            "exported_goods",
            "international_services",
            "prescribed_goods",
            "investment_precious_metals"
        ]
        
        return item_type.lower() in zero_rated_types
    
    def is_exempt_supply(self, item_type: str) -> bool:
        """
        Check if item is GST-exempt
        
        Args:
            item_type: Type of item/service
            
        Returns:
            True if exempt
        """
        exempt_types = [
            "financial_services",
            "residential_property",
            "public_transport",
            "education",
            "healthcare"
        ]
        
        return item_type.lower() in exempt_types