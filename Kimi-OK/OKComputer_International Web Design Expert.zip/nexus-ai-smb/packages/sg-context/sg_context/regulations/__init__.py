"""
Singapore regulations and compliance modules
"""

from .pdpa import PDPAGuidelines
from .gst import GSTRules

__all__ = ["PDPAGuidelines", "GSTRules"]