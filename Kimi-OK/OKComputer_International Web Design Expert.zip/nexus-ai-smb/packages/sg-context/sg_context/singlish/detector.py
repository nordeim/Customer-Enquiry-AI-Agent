"""
Singlish Detector - Detects and analyzes Singapore English patterns
Implements rule-based detection with confidence scoring
"""

import re
from typing import List, Dict, Optional, Tuple
from pydantic import BaseModel, Field
from .patterns import COMPILED_PATTERNS, NORMALIZATION_MAP, SENTIMENT_WEIGHTS


class SinglishToken(BaseModel):
    """Represents a detected Singlish token"""
    token: str
    intent: str
    sentiment: float = Field(ge=-1.0, le=1.0)  # -1.0 to 1.0
    confidence: float = Field(ge=0.0, le=1.0)  # 0.0 to 1.0
    translation: Optional[str] = None
    position: Optional[Tuple[int, int]] = None  # start, end position in text


class SinglishAnnotation(BaseModel):
    """Complete Singlish annotation for a text"""
    original_text: str
    annotated_text: str
    tokens: List[SinglishToken]
    confidence: float = Field(ge=0.0, le=1.0)
    language_mode: str = "en-SG"  # en-SG, singlish, code-switch
    requires_adaptation: bool = False


class SinglishDetector:
    """
    Detects Singlish patterns in text with cultural context awareness
    
    Rationale: Singaporean business owners need to understand when customers
    are using Singlish to gauge sentiment and adjust responses accordingly.
    This enables culturally appropriate customer service.
    """
    
    def __init__(self, threshold: float = 0.3):
        """
        Initialize Singlish detector
        
        Args:
            threshold: Minimum confidence threshold for detection (0.0-1.0)
        """
        self.threshold = threshold
        self.compiled_patterns = COMPILED_PATTERNS
        self.normalization_map = NORMALIZATION_MAP
        self.sentiment_weights = SENTIMENT_WEIGHTS
        
    def detect(self, text: str) -> SinglishAnnotation:
        """
        Detect Singlish patterns in text
        
        Args:
            text: Input text to analyze
            
        Returns:
            SinglishAnnotation with detected tokens and metadata
        """
        if not text or not text.strip():
            return SinglishAnnotation(
                original_text=text,
                annotated_text=text,
                tokens=[],
                confidence=0.0,
                language_mode="en-SG"
            )
        
        text_lower = text.lower()
        tokens = []
        detected_positions = []
        
        # Pattern matching
        for pattern, metadata in self.compiled_patterns.items():
            for match in pattern.finditer(text_lower):
                token_text = match.group()
                intent = metadata.get("intent", "unknown")
                sentiment = metadata.get("sentiment", 0.0)
                
                # Calculate confidence based on pattern type
                confidence = 0.85 if metadata.get("type") == "phrase" else 0.75
                
                # Get translation if available
                translation = metadata.get("translation")
                if not translation and token_text in self.normalization_map:
                    translation = self.normalization_map[token_text]
                
                token = SinglishToken(
                    token=token_text,
                    intent=intent,
                    sentiment=sentiment,
                    confidence=confidence,
                    translation=translation,
                    position=(match.start(), match.end())
                )
                
                tokens.append(token)
                detected_positions.append((match.start(), match.end()))
        
        # Remove overlapping tokens (keep longest match)
        tokens = self._remove_overlapping_tokens(tokens)
        
        # Sort tokens by position
        tokens.sort(key=lambda t: t.position[0] if t.position else 0)
        
        # Calculate overall confidence
        confidence = self._calculate_confidence(text, tokens)
        
        # Determine language mode
        language_mode = self._determine_language_mode(text, tokens, confidence)
        
        # Create annotated text
        annotated_text = self._create_annotated_text(text, tokens)
        
        # Check if cultural adaptation is needed
        requires_adaptation = confidence > self.threshold and len(tokens) > 0
        
        return SinglishAnnotation(
            original_text=text,
            annotated_text=annotated_text,
            tokens=tokens,
            confidence=confidence,
            language_mode=language_mode,
            requires_adaptation=requires_adaptation
        )
    
    def normalize_to_english(self, text: str) -> str:
        """
        Normalize Singlish text to standard English
        
        Args:
            text: Input text with Singlish patterns
            
        Returns:
            Normalized standard English text
        """
        normalized = text
        
        # Apply normalization patterns in order of precedence
        # Longer phrases first to avoid partial replacements
        sorted_patterns = sorted(
            self.normalization_map.items(),
            key=lambda x: len(x[0]),
            reverse=True
        )
        
        for singlish, english in sorted_patterns:
            if english:  # Skip empty replacements (particles)
                pattern = re.compile(re.escape(singlish), re.IGNORECASE)
                normalized = pattern.sub(english, normalized)
        
        # Clean up extra spaces
        normalized = re.sub(r'\s+', ' ', normalized).strip()
        
        return normalized
    
    def detect_batch(self, texts: List[str]) -> List[SinglishAnnotation]:
        """
        Batch process multiple texts
        
        Args:
            texts: List of input texts
            
        Returns:
            List of SinglishAnnotations
        """
        return [self.detect(text) for text in texts]
    
    def get_cultural_context(self, annotation: SinglishAnnotation) -> Dict[str, Any]:
        """
        Extract cultural context from Singlish annotation
        
        Args:
            annotation: SinglishAnnotation to analyze
            
        Returns:
            Cultural context dictionary
        """
        if not annotation.tokens:
            return {
                "requires_adaptation": False,
                "politeness_level": "formal",
                "sentiment": 0.0,
                "cultural_notes": []
            }
        
        # Calculate average sentiment
        avg_sentiment = sum(t.sentiment for t in annotation.tokens) / len(annotation.tokens)
        
        # Determine politeness level based on tokens
        if any(t.intent in ["frustration", "disappointment"] for t in annotation.tokens):
            politeness_level = "urgent"
        elif any(t.intent in ["apology"] for t in annotation.tokens):
            politeness_level = "friendly"
        elif annotation.confidence > 0.7:
            politeness_level = "casual"
        else:
            politeness_level = "formal"
        
        # Cultural notes
        cultural_notes = []
        for token in annotation.tokens:
            if token.intent == "frustration":
                cultural_notes.append(f"Customer expressing frustration: '{token.token}'")
            elif token.intent == "apology":
                cultural_notes.append(f"Customer being apologetic: '{token.token}'")
            elif token.intent == "feasibility_check":
                cultural_notes.append(f"Customer checking possibility: '{token.token}'")
        
        return {
            "requires_adaptation": annotation.requires_adaptation,
            "politeness_level": politeness_level,
            "sentiment": avg_sentiment,
            "cultural_notes": cultural_notes,
            "language_mode": annotation.language_mode
        }
    
    def _remove_overlapping_tokens(self, tokens: List[SinglishToken]) -> List[SinglishToken]:
        """Remove overlapping tokens, keeping the longest match"""
        if not tokens:
            return tokens
        
        # Sort by position and then by length (descending)
        tokens_with_pos = [t for t in tokens if t.position]
        tokens_with_pos.sort(key=lambda t: (t.position[0], -(t.position[1] - t.position[0])))
        
        filtered = []
        last_end = -1
        
        for token in tokens_with_pos:
            start, end = token.position
            if start >= last_end:  # No overlap
                filtered.append(token)
                last_end = end
        
        # Add tokens without positions
        filtered.extend([t for t in tokens if not t.position])
        
        return filtered
    
    def _calculate_confidence(self, text: str, tokens: List[SinglishToken]) -> float:
        """Calculate overall confidence score"""
        if not tokens:
            return 0.0
        
        # Base confidence from token confidences
        avg_token_confidence = sum(t.confidence for t in tokens) / len(tokens)
        
        # Boost confidence based on token density
        text_length = len(text.split())
        token_count = len(tokens)
        density_boost = min(token_count / max(text_length, 1), 1.0) * 0.2
        
        # Adjust for text length (longer texts with few tokens = lower confidence)
        if text_length > 10 and token_count < 2:
            length_penalty = 0.3
        else:
            length_penalty = 0.0
        
        confidence = avg_token_confidence + density_boost - length_penalty
        return max(0.0, min(1.0, confidence))
    
    def _determine_language_mode(self, text: str, tokens: List[SinglishToken], confidence: float) -> str:
        """Determine the language mode based on detection results"""
        if not tokens:
            return "en-SG"
        
        if confidence > 0.8:
            return "singlish"
        elif confidence > 0.5:
            return "code-switch"
        else:
            return "en-SG"
    
    def _create_annotated_text(self, original: str, tokens: List[SinglishToken]) -> str:
        """Create annotated text with token markers"""
        if not tokens:
            return original
        
        # Sort tokens by position (reverse order for insertion)
        sorted_tokens = sorted(
            [t for t in tokens if t.position],
            key=lambda t: t.position[0],
            reverse=True
        )
        
        annotated = original
        
        for token in sorted_tokens:
            if token.position:
                start, end = token.position
                marker = f"[[{token.intent}:{token.token}]]"
                annotated = annotated[:start] + marker + annotated[end:]
        
        return annotated