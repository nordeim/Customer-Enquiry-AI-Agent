"""
Singlish patterns and mappings for detection and normalization
Based on research from the Coxford Singlish Dictionary and local usage
"""

import re
from typing import Dict, List, Pattern

# Singlish particle patterns with their meanings and intents
SINGLISH_PATTERNS = {
    # Emphasis particles
    r"\blah\b": {"intent": "emphasis", "sentiment": 0.0, "type": "particle"},
    r"\bleh\b": {"intent": "emphasis", "sentiment": 0.0, "type": "particle"},
    r"\blor\b": {"intent": "emphasis", "sentiment": 0.0, "type": "particle"},
    r"\bhor\b": {"intent": "question", "sentiment": 0.0, "type": "particle"},
    r"\bmeh\b": {"intent": "question", "sentiment": 0.0, "type": "particle"},
    r"\bah\b": {"intent": "emphasis", "sentiment": 0.0, "type": "particle"},
    r"\bhah\b": {"intent": "emphasis", "sentiment": 0.0, "type": "particle"},
    
    # Emotional expressions
    r"\bwah\b": {"intent": "surprise", "sentiment": 0.3, "type": "expression"},
    r"\bwah lau\b": {"intent": "frustration", "sentiment": -0.7, "type": "expression"},
    r"\bwah piang\b": {"intent": "frustration", "sentiment": -0.8, "type": "expression"},
    r"\baiyah\b": {"intent": "disappointment", "sentiment": -0.5, "type": "expression"},
    r"\baiyoh\b": {"intent": "disappointment", "sentiment": -0.6, "type": "expression"},
    r"\balamak\b": {"intent": "frustration", "sentiment": -0.6, "type": "expression"},
    r"\bpaiseh\b": {"intent": "apology", "sentiment": -0.3, "type": "expression"},
    
    # Feasibility and question patterns
    r"\bcan\s+or\s+not\b": {"intent": "feasibility_check", "sentiment": 0.0, "type": "phrase"},
    r"\bhow\s+come\b": {"intent": "temporal_reference", "sentiment": 0.0, "type": "phrase"},
    r"\blike\s+that\b": {"intent": "temporal_reference", "sentiment": 0.0, "type": "phrase"},
    r"\bso\s+how\b": {"intent": "feasibility_check", "sentiment": 0.0, "type": "phrase"},
    r"\bgot\s+problem\s+meh\b": {"intent": "question", "sentiment": -0.2, "type": "phrase"},
    
    # Common phrases
    r"\bsteady\s+lah\b": {"intent": "emphasis", "sentiment": 0.8, "type": "phrase"},
    r"\bcatch\s+no\s+ball\b": {"intent": "feasibility_check", "sentiment": -0.3, "type": "phrase"},
    r"\bblur\s+like\s+sotong\b": {"intent": "frustration", "sentiment": -0.5, "type": "phrase"},
    r"\bdon't\s+play\s+play\b": {"intent": "emphasis", "sentiment": -0.4, "type": "phrase"},
    r"\bwhy\s+you\s+so\s+like\s+that\b": {"intent": "frustration", "sentiment": -0.6, "type": "phrase"},
    
    # Time references
    r"\btomolo\b": {"intent": "temporal_reference", "sentiment": 0.0, "translation": "tomorrow", "type": "word"},
    r"\btoday\b": {"intent": "temporal_reference", "sentiment": 0.0, "type": "word"},
    r"\btonite\b": {"intent": "temporal_reference", "sentiment": 0.0, "translation": "tonight", "type": "word"},
    
    # Common Singlish words
    r"\bshiok\b": {"intent": "emphasis", "sentiment": 0.7, "type": "word"},
    r"\bsian\b": {"intent": "frustration", "sentiment": -0.6, "type": "word"},
    r"\bkiasu\b": {"intent": "emphasis", "sentiment": -0.2, "type": "word"},
    r"\bkaypoh\b": {"intent": "emphasis", "sentiment": -0.1, "type": "word"},
    r"\blepak\b": {"intent": "emphasis", "sentiment": 0.2, "type": "word"},
    r"\bmakan\b": {"intent": "emphasis", "sentiment": 0.3, "type": "word"},
    r"\bchope\b": {"intent": "emphasis", "sentiment": 0.0, "type": "word"},
    
    # Food-related (common in Singapore context)
    r"\bkopi\b": {"intent": "emphasis", "sentiment": 0.2, "type": "word"},
    r"\bteh\b": {"intent": "emphasis", "sentiment": 0.2, "type": "word"},
    r"\bhawker\b": {"intent": "emphasis", "sentiment": 0.1, "type": "word"},
}

# Normalization mappings: Singlish -> Standard English
NORMALIZATION_MAP = {
    # Particles (usually removed or context-dependent)
    "lah": "",
    "leh": "",
    "lor": "",
    "hor": "",
    "meh": "",
    "ah": "",
    "hah": "",
    
    # Phrases
    "can or not": "is this possible",
    "how come": "why",
    "like that": "in that manner",
    "so how": "what should we do",
    "steady lah": "that's excellent",
    "catch no ball": "do not understand",
    "blur like sotong": "very confused",
    "don't play play": "do not joke about this",
    "why you so like that": "why are you behaving this way",
    "got problem meh": "is there a problem",
    
    # Words
    "tomolo": "tomorrow",
    "tonite": "tonight",
    "got": "have",
    "never": "did not",
    "already": "already",
    "one": "",  # Often just emphasis
    "then": "then",
    "also": "also",
    "but": "but",
    
    # Emotional
    "wah lau": "oh dear",
    "wah piang": "oh my goodness",
    "aiyah": "oh no",
    "aiyoh": "oh dear",
    "alamak": "oh no",
    "paiseh": "sorry",
    "shiok": "great",
    "sian": "boring",
    
    # Common terms
    "makan": "eat",
    "chope": "reserve",
    "lepak": "relax",
    "kaypoh": "nosy",
    "kiasu": "afraid to lose",
}

# Compiled patterns for performance
COMPILED_PATTERNS: Dict[Pattern, Dict[str, Any]] = {
    re.compile(pattern, re.IGNORECASE): metadata 
    for pattern, metadata in SINGLISH_PATTERNS.items()
}

# Sentiment weights for different intents
SENTIMENT_WEIGHTS = {
    "emphasis": 0.0,
    "question": 0.0,
    "feasibility_check": 0.0,
    "temporal_reference": 0.0,
    "surprise": 0.3,
    "apology": -0.3,
    "frustration": -0.7,
    "disappointment": -0.5,
}


def get_pattern_metadata(pattern: str) -> Dict[str, Any]:
    """Get metadata for a specific pattern"""
    return SINGLISH_PATTERNS.get(pattern, {})


def get_sentiment_for_intent(intent: str) -> float:
    """Get default sentiment score for an intent"""
    return SENTIMENT_WEIGHTS.get(intent, 0.0)


# Cultural context mappings
CULTURAL_CONTEXT = {
    "politeness_markers": {
        "en": ["Sir", "Madam", "Uncle", "Aunty"],
        "zh": ["先生", "女士", "叔叔", "阿姨"],
        "ms": ["Encik", "Puan", "Pakcik", "Makcik"],
        "ta": ["ஐயா", "அம்மா", "மாமா", "அத்தை"],
    },
    "formality_levels": {
        "formal": ["Sir", "Madam", "Mr.", "Ms.", "Dr."],
        "casual": ["Uncle", "Aunty", "Bro", "Sis"],
        "friendly": ["Hey", "Hi", "Hello"],
    },
    "business_hours": {
        "start": "09:00",
        "end": "18:00",
        "timezone": "Asia/Singapore",
    },
}