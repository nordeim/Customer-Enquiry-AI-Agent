"""
Test-driven development for SinglishDetector
Tests written before implementation
"""

import pytest
from sg_context.singlish.detector import SinglishDetector, SinglishToken, SinglishAnnotation
from sg_context.singlish.patterns import SINGLISH_PATTERNS


class TestSinglishDetector:
    """Test cases for SinglishDetector"""

    @pytest.fixture
    def detector(self):
        """Create detector instance"""
        return SinglishDetector()

    def test_detect_simple_particles(self, detector):
        """Test detection of common Singlish particles"""
        text = "Can you help me lah"
        result = detector.detect(text)
        
        assert result is not None
        assert len(result.tokens) == 1
        assert result.tokens[0].token == "lah"
        assert result.tokens[0].intent == "emphasis"

    def test_detect_multiple_particles(self, detector):
        """Test detection of multiple Singlish particles"""
        text = "Wah lau this thing spoil already leh"
        result = detector.detect(text)
        
        assert len(result.tokens) >= 2
        tokens = [t.token for t in result.tokens]
        assert "wah lau" in tokens or "leh" in tokens

    def test_detect_feasibility_check(self, detector):
        """Test detection of 'can or not' pattern"""
        text = "Can I return this item or not"
        result = detector.detect(text)
        
        tokens = [t.token for t in result.tokens]
        assert any("can" in t and "not" in t for t in tokens)

    def test_detect_frustration(self, detector):
        """Test detection of frustration expressions"""
        text = "Wah lau why so slow one"
        result = detector.detect(text)
        
        tokens = [t.intent for t in result.tokens]
        assert "frustration" in tokens

    def test_detect_temporal_reference(self, detector):
        """Test detection of temporal references"""
        text = "I need it by tomolo"
        result = detector.detect(text)
        
        tokens = [t.intent for t in result.tokens]
        assert "temporal_reference" in tokens

    def test_detect_apology(self, detector):
        """Test detection of apology expressions"""
        text = "Paiseh I late already"
        result = detector.detect(text)
        
        tokens = [t.intent for t in result.tokens]
        assert "apology" in tokens

    def test_normalize_singlish_to_english(self, detector):
        """Test normalization of Singlish to standard English"""
        text = "Can or not if I return this"
        normalized = detector.normalize_to_english(text)
        
        assert "can or not" not in normalized.lower()
        assert "is this possible" in normalized.lower()

    def test_code_switching_detection(self, detector):
        """Test detection of code-switching (English + Chinese/Malay)"""
        text = "This one very shiok lah"
        result = detector.detect(text)
        
        # Should detect both English and Singlish elements
        assert result.confidence > 0.5

    def test_confidence_scoring(self, detector):
        """Test confidence scoring for different inputs"""
        # High confidence for clear Singlish
        clear_singlish = "Can or not lah"
        result1 = detector.detect(clear_singlish)
        assert result1.confidence > 0.8
        
        # Lower confidence for ambiguous cases
        ambiguous = "Can I do this"
        result2 = detector.detect(ambiguous)
        assert result2.confidence < 0.5

    def test_empty_text_handling(self, detector):
        """Test handling of empty or invalid inputs"""
        result = detector.detect("")
        assert result is not None
        assert len(result.tokens) == 0
        assert result.confidence == 0.0

    def test_special_characters_handling(self, detector):
        """Test handling of special characters and punctuation"""
        text = "Wah lau! This thing spoil already... leh?"
        result = detector.detect(text)
        
        # Should still detect particles despite punctuation
        tokens = [t.token for t in result.tokens]
        assert any(t in ["wah lau", "leh"] for t in tokens)

    @pytest.mark.parametrize("text,expected_intent", [
        ("How come like that one", "temporal_reference"),
        ("Steady lah this plan", "emphasis"),
        ("Blur like sotong", "frustration"),
        ("Catch no ball what you saying", "feasibility_check"),
        ("Why you so like that", "frustration"),
        ("Don't play play ah", "emphasis"),
        ("Got problem meh", "question"),
        ("Alamak I forgot already", "disappointment"),
    ])
    def test_comprehensive_patterns(self, detector, text, expected_intent):
        """Test comprehensive pattern matching"""
        result = detector.detect(text)
        
        intents = [t.intent for t in result.tokens]
        assert expected_intent in intents or len(result.tokens) > 0

    def test_annotation_preserves_original(self, detector):
        """Test that annotation preserves original text"""
        original = "Can or not lah if I return this item"
        result = detector.detect(original)
        
        assert result.original_text == original
        assert result.annotated_text is not None
        assert len(result.annotated_text) > 0

    def test_batch_processing(self, detector):
        """Test batch processing of multiple texts"""
        texts = [
            "Can or not",
            "Wah lau so slow",
            "Paiseh I late",
            "This one good lah"
        ]
        
        results = detector.detect_batch(texts)
        assert len(results) == len(texts)
        assert all(r.confidence > 0 for r in results)