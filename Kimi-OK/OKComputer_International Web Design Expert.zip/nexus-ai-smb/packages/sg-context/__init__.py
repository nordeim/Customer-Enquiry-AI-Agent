"""
Singapore Context Library
Version: 1.0.0
Provides cultural, regulatory, and linguistic utilities specific to Singapore.
"""

from .singlish.detector import SinglishDetector, SinglishAnnotation, SinglishToken
from .pii.detector import SingaporePIIDetector, RedactionResult
from .regulations.pdpa import PDPAGuidelines
from .regulations.gst import GSTRules

__all__ = [
    "SinglishDetector",
    "SinglishAnnotation", 
    "SinglishToken",
    "SingaporePIIDetector",
    "RedactionResult",
    "PDPAGuidelines",
    "GSTRules",
]

__version__ = "1.0.0"