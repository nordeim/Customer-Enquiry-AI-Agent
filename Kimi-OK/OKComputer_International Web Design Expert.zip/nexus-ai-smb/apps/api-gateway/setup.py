"""
Setup script for Nexus AI SMB API Gateway
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="nexus-ai-smb-api-gateway",
    version="2.1.0",
    description="Singapore-optimized AI customer service API gateway",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.11",
    install_requires=[
        "fastapi>=0.115.0",
        "uvicorn[standard]>=0.24.0",
        "pydantic>=2.9.2",
        "langgraph>=0.2.39",
        "openai>=1.3.0",
        "qdrant-client>=1.12.0",
        "redis>=5.0.8",
        "asyncpg>=0.29.0",
        "sqlalchemy>=2.0.23",
        "presidio-analyzer>=2.2.355",
        "presidio-anonymizer>=2.2.355",
        "python-jose[cryptography]>=3.3.0",
        "passlib[bcrypt]>=1.7.4",
        "structlog>=23.2.0",
        "python-dotenv>=1.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.3",
            "pytest-asyncio>=0.21.1",
            "pytest-cov>=4.1.0",
            "ruff>=0.1.6",
            "mypy>=1.7.1",
        ],
    },
    entry_points={
        "console_scripts": [
            "nexus-api=app.main:main",
        ],
    },
)