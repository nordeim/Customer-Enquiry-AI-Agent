"""
Nexus AI SMB API Gateway - FastAPI Main Application
Singapore-optimized AI customer service agent
"""

import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse
import structlog
from redis import asyncio as aioredis
import os

from .routers import webhook, websocket, health
from .services.redis_service import RedisService
from .services.agent_service import AgentService
from .utils.logging import setup_logging

# Setup structured logging
logger = structlog.get_logger(__name__)

# Global services
redis_service: Optional[RedisService] = None
agent_service: Optional[AgentService] = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    logger.info("Starting Nexus AI SMB API Gateway", version="2.1.0")
    
    # Initialize Redis
    global redis_service
    redis_url = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    redis_service = RedisService(redis_url)
    await redis_service.connect()
    logger.info("Connected to Redis")
    
    # Initialize Agent Service
    global agent_service
    agent_service = AgentService(redis_service)
    await agent_service.initialize()
    logger.info("Agent service initialized")
    
    yield
    
    # Shutdown
    logger.info("Shutting down API Gateway")
    if redis_service:
        await redis_service.disconnect()
    if agent_service:
        await agent_service.cleanup()


# Create FastAPI app
app = FastAPI(
    title="Nexus AI SMB API Gateway",
    description="Singapore-optimized AI customer service agent",
    version="2.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# Security middleware
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=["*"]  # Configure based on deployment
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(webhook.router, prefix="/api/v1/webhook", tags=["webhook"])
app.include_router(websocket.router, prefix="/ws", tags=["websocket"])
app.include_router(health.router, prefix="/health", tags=["health"])


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """General exception handler"""
    logger.error(
        "Unhandled exception",
        error=str(exc),
        path=request.url.path,
        method=request.method
    )
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "message": "An unexpected error occurred",
            "timestamp": datetime.now().isoformat()
        }
    )


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """HTTP exception handler"""
    logger.warning(
        "HTTP exception",
        status_code=exc.status_code,
        detail=exc.detail,
        path=request.url.path
    )
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "timestamp": datetime.now().isoformat()
        }
    )


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "Nexus AI SMB API Gateway",
        "version": "2.1.0",
        "description": "Singapore-optimized AI customer service agent",
        "status": "running",
        "features": [
            "WhatsApp Business API Integration",
            "Singlish Detection",
            "PDPA Compliance",
            "Real-time Dashboard",
            "Multi-language Support"
        ],
        "endpoints": {
            "docs": "/docs",
            "health": "/health",
            "webhook": "/api/v1/webhook",
            "websocket": "/ws"
        }
    }


@app.get("/info")
async def info():
    """Application info endpoint"""
    return {
        "version": "2.1.0",
        "build_time": "2024-12-31T00:00:00Z",
        "timezone": "Asia/Singapore",
        "features": {
            "singlish_detection": True,
            "pdpa_compliance": True,
            "whatsapp_integration": True,
            "redis_streams": True,
            "websocket_support": True
        },
        "compliance": {
            "pdpa": "2022",
            "imda_governance": "framework_v1"
        }
    }


# Main entry point
def main():
    """Main entry point for running the application"""
    import uvicorn
    
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8000"))
    reload = os.getenv("RELOAD", "false").lower() == "true"
    
    uvicorn.run(
        "app.main:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info"
    )


if __name__ == "__main__":
    main()