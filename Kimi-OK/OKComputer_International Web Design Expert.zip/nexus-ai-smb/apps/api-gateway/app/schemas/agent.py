"""
Agent state and reasoning schemas
Implements LangGraph-compatible state management
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field


class AgentStep(str, Enum):
    """Agent processing steps"""
    IDLE = "idle"
    PII_CHECK = "pii_check"
    INTENT_CLASSIFY = "intent_classify"
    CULTURAL_ANALYSIS = "cultural_analysis"
    RAG_RETRIEVE = "rag_retrieve"
    LLM_GENERATE = "llm_generate"
    SAFETY_CHECK = "safety_check"
    RESPONSE_DELIVER = "response_deliver"
    ERROR_HANDLE = "error_handle"


class ReasoningType(str, Enum):
    """Types of reasoning steps"""
    INTENT = "intent"
    RETRIEVAL = "retrieval"
    GENERATION = "generation"
    SAFETY = "safety"
    ESCALATION = "escalation"


class SingaporeBusinessContext(BaseModel):
    """Singapore SMB-specific business context"""
    uen: str
    industry: str = Field(
        description="Industry: f&b, retail, logistics, professional_services"
    )
    gst_registered: bool = False
    staff_size: int = Field(ge=1, le=200)
    operating_hours: Dict[str, str] = {
        "start": "09:00",
        "end": "18:00",
        "timezone": "Asia/Singapore"
    }
    preferred_language: str = "en"


class SingaporeSentiment(BaseModel):
    """Singapore-specific sentiment analysis"""
    score: float = Field(ge=-1.0, le=1.0)
    detected_emotion: Optional[str] = Field(
        description="frustrated, urgent, kiasu, satisfied, confused"
    )
    requires_empathy: bool = False
    cultural_note: Optional[str] = Field(
        description="Singapore cultural consideration for response"
    )


class AgentState(BaseModel):
    """Enhanced agent state with Singapore context"""
    # Core conversation state
    session_id: str
    user_id: str
    messages: List[Dict[str, Any]] = []
    
    # Current processing step
    current_step: AgentStep = AgentStep.IDLE
    
    # Singapore Business Context
    business_context: Optional[SingaporeBusinessContext] = None
    
    # Singapore-Specific Analysis
    sentiment: Optional[SingaporeSentiment] = None
    contains_singlish: bool = False
    requires_pdpa_check: bool = False
    estimated_resolution_time: int = 0  # Minutes
    
    # Memory Layers (Singapore-optimized)
    long_term_facts: List[str] = []
    short_term_context: List[str] = []
    working_memory: str = ""
    
    # Singapore Regulations Cache
    pdpa_guidelines: List[str] = []
    gst_rules: List[str] = []
    
    # Escalation Metrics
    escalation_risk: float = 0.0
    human_available: bool = False
    last_human_escalation: Optional[datetime] = None
    
    # Performance tracking
    start_time: datetime = Field(default_factory=datetime.now)
    step_timings: Dict[str, float] = {}


class LLMConfig(BaseModel):
    """LLM configuration"""
    model: str = Field(pattern=r"^(gpt-4o-mini|gpt-4o|gpt-3.5-turbo)$")
    temperature: float = Field(ge=0.0, le=2.0, default=0.2)
    max_tokens: int = Field(default=1000, gt=0)
    top_p: float = Field(ge=0.0, le=1.0, default=0.9)


class RAGConfig(BaseModel):
    """RAG configuration"""
    top_k: int = Field(default=5, gt=0, le=20)
    score_threshold: float = Field(ge=0.0, le=1.0, default=0.7)
    hybrid_search: bool = True
    rerank: bool = True


class SingaporeConfig(BaseModel):
    """Singapore-specific configuration"""
    singlish_mode: str = Field(
        default="auto",
        pattern=r"^(auto|always|never)$"
    )
    cultural_adaptation: bool = True
    politeness_default: str = Field(
        default="casual",
        pattern=r"^(formal|casual|friendly)$"
    )
    business_hours_only: bool = False


class ComplianceConfig(BaseModel):
    """Compliance configuration"""
    pdpa_mode: str = Field(
        default="strict",
        pattern=r"^(strict|permissive|bypass)$"
    )
    audit_everything: bool = True
    data_retention_days: int = Field(default=90, gt=0)


class EscalationConfig(BaseModel):
    """Escalation configuration"""
    enabled: bool = True
    confidence_threshold: float = Field(ge=0.0, le=1.0, default=0.3)
    sentiment_threshold: float = Field(ge=-1.0, le=0.0, default=-0.5)
    timeout_seconds: int = Field(default=30, gt=0)


class AgentConfig(BaseModel):
    """Complete agent configuration"""
    llm: LLMConfig = Field(default_factory=LLMConfig)
    rag: RAGConfig = Field(default_factory=RAGConfig)
    singapore: SingaporeConfig = Field(default_factory=SingaporeConfig)
    compliance: ComplianceConfig = Field(default_factory=ComplianceConfig)
    escalation: EscalationConfig = Field(default_factory=EscalationConfig)


class ReasoningStep(BaseModel):
    """Individual reasoning step"""
    step: str
    type: ReasoningType
    input: Optional[str] = None
    output: Optional[str] = None
    confidence: Optional[float] = Field(None, ge=0.0, le=1.0)
    timestamp: datetime = Field(default_factory=datetime.now)
    latency_ms: int = Field(gt=0)
    
    # Singapore-specific reasoning
    cultural_notes: Optional[List[Dict[str, str]]] = None
    
    # Retrieval details
    retrieved_chunks: Optional[List[Dict[str, Any]]] = None
    
    # Safety checks
    safety_checks: Optional[List[Dict[str, Any]]] = None


class RetrievedChunk(BaseModel):
    """Retrieved context chunk"""
    id: str
    content: str
    score: float
    source: str
    relevance: float = Field(ge=0.0, le=1.0)


class AgentReasoning(BaseModel):
    """Complete agent reasoning trace"""
    steps: List[ReasoningStep] = []
    total_latency_ms: int = Field(gt=0)
    confidence: float = Field(ge=0.0, le=1.0)
    cultural_adaptation: bool = False
    retrieved_chunks: Optional[List[RetrievedChunk]] = None


class AgentResponseMetadata(BaseModel):
    """Response metadata"""
    session_id: str
    message_id: str
    requires_escalation: bool = False
    escalation_reason: Optional[str] = None
    pii_detected: bool = False
    tokens_used: Optional[Dict[str, int]] = None


class SingaporeResponseContext(BaseModel):
    """Singapore-specific response context"""
    detected_language: str
    cultural_context: Dict[str, Any]
    compliance_flags: Optional[List[str]] = None


class AgentResponse(BaseModel):
    """Complete agent response"""
    message: Dict[str, Any]
    reasoning: AgentReasoning
    metadata: AgentResponseMetadata
    singapore: SingaporeResponseContext


class AgentMetrics(BaseModel):
    """Agent performance metrics"""
    session_id: str
    total_messages: int
    average_response_time: float
    singlish_detection_accuracy: float
    escalation_rate: float
    customer_satisfaction: float
    pii_incidents: int
    compliance_score: float