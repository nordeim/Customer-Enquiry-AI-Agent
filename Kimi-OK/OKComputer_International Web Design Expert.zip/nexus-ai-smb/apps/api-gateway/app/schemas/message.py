"""
Message schemas with Singapore-specific cultural context
Implements PDPA compliance through metadata tracking
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum
from pydantic import BaseModel, Field, field_validator
import re


class LanguageMode(str, Enum):
    """Singapore language modes"""
    EN_SG = "en-SG"
    SINGLISH = "singlish"
    ZH_SG = "zh-SG"
    MS_SG = "ms-SG"
    TA_SG = "ta-SG"
    CODE_SWITCH = "code-switch"


class IntentType(str, Enum):
    """Singlish intent classifications"""
    FEASIBILITY_CHECK = "feasibility_check"    # "can or not"
    FRUSTRATION = "frustration"          # "wah lau"
    TEMPORAL_REFERENCE = "temporal_reference"   # "tomolo"
    APOLOGY = "apology"              # "paiseh"
    EMPHASIS = "emphasis"             # "lah", "leh", "lor"
    QUESTION = "question"             # "meh", "hor"
    SURPRISE = "surprise"             # "wah"
    DISAPPOINTMENT = "disappointment"      # "aiyah", "aiyoh"


class PolitenessLevel(str, Enum):
    """Politeness hierarchy for Singapore context"""
    FORMAL = "formal"
    CASUAL = "casual"
    FRIENDLY = "friendly"
    URGENT = "urgent"


class PIType(str, Enum):
    """Personal information types for PDPA compliance"""
    NRIC = "NRIC"
    FIN = "FIN"
    PHONE_SG = "PHONE_SG"
    EMAIL = "EMAIL"
    ADDRESS = "ADDRESS"
    CREDIT_CARD = "CREDIT_CARD"


class MessageStatus(str, Enum):
    """Message delivery status"""
    SENDING = "sending"
    SENT = "sent"
    DELIVERED = "delivered"
    READ = "read"
    FAILED = "failed"


class ConversationStatus(str, Enum):
    """Conversation status"""
    ACTIVE = "active"
    CLOSED = "closed"
    ESCALATED = "escalated"
    WAITING = "waiting"


class EscalationReason(str, Enum):
    """Reasons for human escalation"""
    COMPLEX_QUERY = "complex_query"
    COMPLAINT = "complaint"
    TECHNICAL_ISSUE = "technical_issue"
    PII_LEAK = "pii_leak"
    CULTURAL_MISMATCH = "cultural_mismatch"


class SinglishToken(BaseModel):
    """Represents a detected Singlish token with metadata"""
    token: str
    intent: IntentType
    sentiment: float = Field(ge=-1.0, le=1.0)  # -1.0 to 1.0
    confidence: float = Field(ge=0.0, le=1.0)  # 0.0 to 1.0
    translation: Optional[str] = None  # Standard English equivalent


class CulturalMeta(BaseModel):
    """Cultural context metadata for Singapore"""
    language_mode: LanguageMode
    tokens: Optional[List[SinglishToken]] = None
    confidence: float = Field(ge=0.0, le=1.0)
    requires_cultural_adaptation: bool = False
    politeness_level: PolitenessLevel = PolitenessLevel.CASUAL


class PIIMetadata(BaseModel):
    """PII handling metadata for PDPA compliance"""
    redacted: bool
    entities: Optional[List[Dict[str, Any]]] = None
    consent_captured: Optional[bool] = None
    consent_type: Optional[str] = None  # explicit, implied, withdrawn


class BusinessContext(BaseModel):
    """Singapore business context"""
    uen: str  # Unique Entity Number
    industry: str = Field(
        pattern=r"^(f&b|retail|logistics|professional_services|healthcare|education)$"
    )
    gst_registered: bool
    staff_size: int = Field(ge=1, le=200)
    operating_hours: Dict[str, str]
    preferred_language: str = Field(pattern=r"^(en|zh|ms|ta)$")


class MessageMetadata(BaseModel):
    """Message metadata including compliance tracking"""
    pii: PIIMetadata
    timestamp: datetime
    message_id: Optional[str] = None  # WhatsApp message ID
    user_id: Optional[str] = None  # Hashed phone number
    session_id: Optional[str] = None
    
    # Business context
    requires_escalation: bool = False
    escalation_reason: Optional[EscalationReason] = None
    resolution_time: Optional[float] = None  # seconds
    business_context: Optional[BusinessContext] = None


class Message(BaseModel):
    """Core message schema with Singapore context"""
    id: str
    conversation_id: str
    sender: str = Field(pattern=r"^(user|agent|system|human_escalated)$")
    text: str
    
    # Singapore-specific fields
    original_text: Optional[str] = None  # Before any processing
    cultural_meta: Optional[CulturalMeta] = None
    metadata: MessageMetadata
    status: MessageStatus
    
    # Agent reasoning for transparency
    reasoning: Optional[Dict[str, Any]] = None

    @field_validator('text')
    @classmethod
    def validate_text_length(cls, v: str) -> str:
        if len(v) > 4096:
            raise ValueError('Message text exceeds maximum length of 4096 characters')
        return v


class ConversationMetrics(BaseModel):
    """Singapore-specific conversation metrics"""
    singlish_ratio: Optional[float] = Field(None, ge=0.0, le=1.0)
    average_response_time: Optional[float] = None
    resolution_rate: Optional[float] = Field(None, ge=0.0, le=1.0)
    customer_satisfaction: Optional[float] = Field(None, ge=1.0, le=5.0)


class EscalationData(BaseModel):
    """Human escalation tracking"""
    escalated_at: Optional[datetime] = None
    escalated_to: Optional[str] = None  # User ID of human agent
    reason: Optional[str] = None
    resolution: Optional[str] = None


class Conversation(BaseModel):
    """Conversation with Singapore business context"""
    id: str
    user_id: str
    status: ConversationStatus
    started_at: datetime
    last_activity: datetime
    messages: List[Message] = []
    metrics: Optional[ConversationMetrics] = None
    escalation: Optional[EscalationData] = None


# WhatsApp-specific schemas
class WhatsAppMessageType(str, Enum):
    TEXT = "text"
    IMAGE = "image"
    DOCUMENT = "document"
    LOCATION = "location"
    INTERACTIVE = "interactive"


class WhatsAppMessage(BaseModel):
    """WhatsApp message structure"""
    id: str
    from_number: str  # Phone number
    timestamp: str
    type: WhatsAppMessageType
    text: Optional[Dict[str, str]] = None
    context: Optional[Dict[str, str]] = None


class WhatsAppWebhook(BaseModel):
    """WhatsApp webhook payload structure"""
    object: str = Field(default="whatsapp_business_account")
    entry: List[Dict[str, Any]]

    @field_validator('entry')
    @classmethod
    def validate_entry_structure(cls, v: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not v:
            raise ValueError('Entry cannot be empty')
        return v


# Pydantic models for API responses
class MessageResponse(BaseModel):
    """API response for message operations"""
    success: bool
    message: Message
    timestamp: datetime = Field(default_factory=datetime.now)


class ConversationResponse(BaseModel):
    """API response for conversation operations"""
    success: bool
    conversation: Conversation
    timestamp: datetime = Field(default_factory=datetime.now)


class ErrorResponse(BaseModel):
    """Standardized error response"""
    success: bool = False
    error: str
    details: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=datetime.now)