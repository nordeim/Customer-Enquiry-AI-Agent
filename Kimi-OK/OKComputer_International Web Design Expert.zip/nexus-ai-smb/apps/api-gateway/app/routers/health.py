"""
Health check endpoints
"""

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse
import structlog
from typing import Dict, Any

logger = structlog.get_logger(__name__)
router = APIRouter()


@router.get("/")
async def health_check():
    """Basic health check"""
    return JSONResponse(
        content={
            "status": "healthy",
            "service": "nexus-ai-smb-api",
            "version": "2.1.0",
            "timestamp": "2024-12-31T00:00:00Z"
        }
    )


@router.get("/detailed")
async def detailed_health():
    """Detailed health check with dependencies"""
    from datetime import datetime
    
    # Check Redis connectivity
    redis_status = "unknown"
    try:
        from ..services.redis_service import RedisService
        redis = RedisService()
        await redis.connect()
        redis_status = "healthy"
        await redis.disconnect()
    except Exception as e:
        redis_status = f"unhealthy: {str(e)}"
    
    # Check Qdrant connectivity
    qdrant_status = "unknown"
    try:
        import httpx
        async with httpx.AsyncClient() as client:
            response = await client.get("http://localhost:6333/health")
            qdrant_status = "healthy" if response.status_code == 200 else "unhealthy"
    except Exception as e:
        qdrant_status = f"unhealthy: {str(e)}"
    
    # Check OpenAI API
    openai_status = "unknown"
    try:
        import openai
        client = openai.AsyncOpenAI()
        # Lightweight check (list models)
        await client.models.list()
        openai_status = "healthy"
    except Exception as e:
        openai_status = f"unhealthy: {str(e)}"
    
    dependencies = {
        "redis": redis_status,
        "qdrant": qdrant_status,
        "openai": openai_status
    }
    
    # Overall health
    overall_health = "healthy"
    if any(status.startswith("unhealthy") for status in dependencies.values()):
        overall_health = "degraded"
    
    return JSONResponse(
        content={
            "status": overall_health,
            "service": "nexus-ai-smb-api",
            "version": "2.1.0",
            "timestamp": datetime.now().isoformat(),
            "dependencies": dependencies,
            "features": {
                "singlish_detection": True,
                "pdpa_compliance": True,
                "whatsapp_integration": True,
                "redis_streams": True,
                "websocket_support": True
            }
        }
    )


@router.get("/ready")
async def readiness_check():
    """Kubernetes readiness check"""
    # Check if all critical dependencies are ready
    try:
        from ..services.redis_service import RedisService
        redis = RedisService()
        await redis.connect()
        await redis.disconnect()
        
        return JSONResponse(content={"status": "ready"})
    except Exception:
        return JSONResponse(
            content={"status": "not_ready"},
            status_code=503
        )


@router.get("/live")
async def liveness_check():
    """Kubernetes liveness check"""
    return JSONResponse(content={"status": "alive"})