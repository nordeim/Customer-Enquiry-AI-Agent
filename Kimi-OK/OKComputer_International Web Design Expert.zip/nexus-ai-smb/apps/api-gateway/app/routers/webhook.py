"""
WhatsApp Webhook Handler
Handles incoming WhatsApp messages from Meta Cloud API
"""

import hmac
import hashlib
import json
from typing import Optional
from fastapi import APIRouter, HTTPException, BackgroundTasks, Request, Header
from fastapi.responses import JSONResponse
import structlog

from ..schemas.message import WhatsAppWebhook
from ..services.redis_service import RedisService
from ..services.agent_service import AgentService

logger = structlog.get_logger(__name__)
router = APIRouter()

# Global services (injected)
redis_service: Optional[RedisService] = None
agent_service: Optional[AgentService] = None


def set_services(redis: RedisService, agent: AgentService):
    """Set global services"""
    global redis_service, agent_service
    redis_service = redis
    agent_service = agent


def verify_signature(payload: bytes, signature: str, secret: str) -> bool:
    """
    Verify WhatsApp webhook signature using HMAC-SHA256
    
    Args:
        payload: Raw request payload
        signature: X-Hub-Signature-256 header value
        secret: WhatsApp app secret
        
    Returns:
        True if signature is valid
    """
    if not signature.startswith("sha256="):
        return False
    
    expected_signature = hmac.new(
        secret.encode("utf-8"),
        payload,
        hashlib.sha256
    ).hexdigest()
    
    provided_signature = signature[7:]  # Remove "sha256=" prefix
    
    # Use secure comparison
    return hmac.compare_digest(expected_signature, provided_signature)


async def process_whatsapp_message(webhook_data: dict):
    """
    Process WhatsApp message in background
    
    Args:
        webhook_data: Parsed webhook data
    """
    try:
        logger.info("Processing WhatsApp message", data=webhook_data)
        
        # Extract message from webhook
        entry = webhook_data.get("entry", [{}])[0]
        changes = entry.get("changes", [{}])[0]
        value = changes.get("value", {})
        
        messages = value.get("messages", [])
        if not messages:
            logger.warning("No messages found in webhook")
            return
        
        message = messages[0]
        from_number = message.get("from")
        text_body = message.get("text", {}).get("body", "")
        message_id = message.get("id")
        
        # Publish to Redis Stream for guaranteed delivery
        if redis_service:
            await redis_service.publish_message(
                "whatsapp_messages",
                {
                    "from": from_number,
                    "text": text_body,
                    "message_id": message_id,
                    "timestamp": message.get("timestamp"),
                    "webhook_id": webhook_data.get("id")
                }
            )
        
        # Process with agent service
        if agent_service and text_body:
            response = await agent_service.process_message(
                user_id=from_number,
                message=text_body,
                message_id=message_id
            )
            
            # Send response back via WhatsApp (implementation depends on WhatsApp client)
            logger.info("Agent response generated", response=response)
        
    except Exception as e:
        logger.error("Error processing WhatsApp message", error=str(e))
        # Don't raise - WhatsApp requires 200 OK response


@router.post("/whatsapp")
async def whatsapp_webhook(
    request: Request,
    background_tasks: BackgroundTasks,
    x_hub_signature_256: Optional[str] = Header(None)
):
    """
    WhatsApp webhook endpoint
    
    Receives messages from Meta Cloud API and processes them asynchronously
    """
    # Get webhook secret from environment
    secret = request.app.state.config.get("WHATSAPP_APP_SECRET", "")
    if not secret:
        logger.error("WhatsApp app secret not configured")
        raise HTTPException(status_code=500, detail="Webhook not properly configured")
    
    # Read raw payload for signature verification
    payload = await request.body()
    
    # Verify signature if provided
    if x_hub_signature_256:
        if not verify_signature(payload, x_hub_signature_256, secret):
            logger.warning("Invalid webhook signature")
            raise HTTPException(status_code=401, detail="Invalid signature")
    
    try:
        # Parse webhook data
        webhook_data = json.loads(payload)
        
        # Validate webhook structure
        if webhook_data.get("object") != "whatsapp_business_account":
            logger.warning("Invalid webhook object type")
            return JSONResponse(content={"status": "ignored"})
        
        # Add background task for processing
        background_tasks.add_task(process_whatsapp_message, webhook_data)
        
        # Return 200 OK immediately (WhatsApp requirement)
        return JSONResponse(content={"status": "received"})
        
    except json.JSONDecodeError:
        logger.error("Invalid JSON in webhook payload")
        raise HTTPException(status_code=400, detail="Invalid JSON")
    except Exception as e:
        logger.error("Webhook processing error", error=str(e))
        # Still return 200 to WhatsApp, log error internally
        return JSONResponse(content={"status": "received"})


@router.get("/whatsapp")
async def whatsapp_verify(
    hub_mode: Optional[str] = None,
    hub_challenge: Optional[str] = None,
    hub_verify_token: Optional[str] = None
):
    """
    WhatsApp webhook verification endpoint
    
    Used during webhook setup to verify endpoint ownership
    """
    # Get verify token from environment
    verify_token = os.getenv("WHATSAPP_VERIFY_TOKEN", "")
    
    if hub_mode == "subscribe" and hub_verify_token == verify_token:
        logger.info("WhatsApp webhook verified successfully")
        return JSONResponse(content={"hub.challenge": hub_challenge})
    
    logger.warning("WhatsApp webhook verification failed")
    raise HTTPException(status_code=403, detail="Verification failed")


@router.post("/test")
async def test_webhook(request: Request):
    """
    Test webhook endpoint for development
    """
    data = await request.json()
    logger.info("Test webhook received", data=data)
    
    # Process test message
    if agent_service:
        response = await agent_service.process_message(
            user_id="test_user",
            message=data.get("message", ""),
            message_id="test_001"
        )
        return JSONResponse(content={
            "status": "processed",
            "response": response
        })
    
    return JSONResponse(content={"status": "received", "data": data})